# AI Career Recommendation System

An educational content/skill-based career recommendation demo built with Python, scikit-learn and Streamlit. The dataset is synthetic and is not validated for real-world career decisions.

## Google Colab
1. Upload `AI_Career_Training.ipynb` to https://colab.research.google.com/.
2. Run all cells in order. Download `career_model.joblib` and optionally `career_dataset.csv` from the Colab Files panel.
3. Upload `career_model.joblib` to the same GitHub repository directory as `app.py`.

## GitHub
Create a public repository, upload `app.py`, `requirements.txt`, `README.md`, `AI_Career_Training.ipynb`, `career_model.joblib`, and optionally `career_dataset.csv`. Commit changes. Never load untrusted joblib files.

## Streamlit
At https://share.streamlit.io/, create an app from the GitHub repository, select branch `main` and entrypoint `app.py`, then deploy.

## Local run
`pip install -r requirements.txt`
`streamlit run app.py`

## Note
The model learns from generated archetypes, not actual student outcomes. Its holdout accuracy measures performance on similarly synthetic samples only. Use recommendations for exploration, not consequential decisions.
